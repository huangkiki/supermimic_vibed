"""CPU verification using the retained complete native gradient mean files."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
import os
from pathlib import Path

import numpy as np
import torch


def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()

p=argparse.ArgumentParser();p.add_argument('--parent',type=Path,required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:2]);torch.set_num_threads(2)
r=args.input;parent=args.parent
summary=json.loads((r/'reference-gradient-summary.json').read_text());draws=json.loads((r/'reference-gradient-draws.json').read_text())
assert summary['status']=='complete'
assert sha(r/'reference-gradient-means.pt')==summary['mean_sha256']
ref=torch.load(r/'reference-gradient-means.pt',map_location='cpu',weights_only=True)
means=torch.load(parent/'gradient-means.pt',map_location='cpu',weights_only=True)
parent_summary=json.loads((parent/'audit-summary.json').read_text())
assert sha(parent/'gradient-means.pt')==parent_summary['gradient_means_sha256']
section=slice(summary['bias_offset'],summary['bias_offset']+summary['bias_dimensions'])
assert set(ref)==set(summary['statistics'])
n=len(draws)
for method,vector in ref.items():
 stat=summary['statistics'][method]
 assert stat['samples']==n==64
 assert vector.numel()==parent_summary['parameter_count'] and torch.isfinite(vector).all()
 np.testing.assert_allclose(float(vector.double().norm()),stat['mean_l2'],rtol=1e-6)
 np.testing.assert_allclose(vector[section].numpy(),np.mean([x[method]['bias'] for x in draws],axis=0),rtol=1e-6,atol=1e-8)
 variance=(math.fsum(x[method]['l2']**2 for x in draws)-n*stat['mean_l2']**2)/(n-1)
 np.testing.assert_allclose(variance,stat['variance_trace'],rtol=2e-8,atol=1e-7)
 np.testing.assert_allclose(math.sqrt(max(0.,variance)/n),stat['mean_standard_error_l2'],rtol=1e-7,atol=1e-7)
errors=defaultdict(list)
for row in json.loads((r/'reference-error-differences.json').read_text()):
 errors[(row['left'],row['right'],row['reference'])].append(row['squared_error_difference'])
assert len(errors)==14
checks=[]
for (left,right,reference),samples in errors.items():
 a,b=means[left].double(),means[right].double();g=ref[reference].double()
 expected=float(a@a-b@b-2*g@(a-b))
 np.testing.assert_allclose(expected,np.mean(samples),rtol=2e-6,atol=1e-4)
 checks.append(dict(left=left,right=right,reference=reference,mean_from_full_vectors=expected,mean_from_draw_scalars=float(np.mean(samples))))
assert not torch.cuda.is_initialized()
result=dict(status='passed',cuda_initialized=False,reference_means_sha256=sha(r/'reference-gradient-means.pt'),
 parent_means_sha256=sha(parent/'gradient-means.pt'),full_reference_vectors=4,noise_batches=n,full_parameter_count=parent_summary['parameter_count'],
 vector_norms_and_bias_checked=True,variance_conservation_checked=True,error_difference_checks=checks,
 tolerance='FP64 norms/variance; stored FP32 vector error-differences rtol2e-6/atol1e-4')
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='error_difference_checks'},indent=2))
