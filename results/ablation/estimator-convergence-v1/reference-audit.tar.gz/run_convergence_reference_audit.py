"""Post-hoc reproducibility audit of direction0/seed40027; original results retained."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023')
REPO=ROOT/'estimator-convergence-repo'
OUT=ROOT/'runtime/estimator-convergence-reference-audit-v1'
PRIMARY=ROOT/'runtime/estimator-convergence-v1'
sys.path.insert(0,str(REPO))
from experiments.ablation.common import sha256,write_json
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu

primary=json.loads((PRIMARY/'campaign.json').read_text())
assert primary['status']=='complete'
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert source==primary['source']=='5e1ac4548334a3dcbdccdaafb60683dae86905f5'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip()
OUT.mkdir(exist_ok=False)
os.nice(10)
affinity=sorted(os.sched_getaffinity(0))[-4:];os.sched_setaffinity(0,affinity)
record=dict(status='running',source=source,parent_campaign_sha256=sha256(PRIMARY/'campaign.json'),
    parent_allocated_gpu_hours=primary['allocated_gpu_hours'],combined_cap_gpu_hours=1.,
    question='Do the large physical finite differences for preselected direction0 and noise40027 repeat across fresh processes?',
    selection='Post-hoc diagnostic of a large-difference tape; not a new independent direction/noise sample or replacement primary result',
    repetitions=3,reference_seeds=[40027,40001],estimator_seeds=[30001,30002],direction_seed=50001,directions=1,
    epsilons=[.003,.01,.03],horizon=32,starts=[0,1],action_std=.1,baseline_repeats=3,
    forecast_seconds_per_process=70,maximum_seconds_per_process=90,projected_peak_memory_mib=4096,
    minimum_disk_reserve_gib=16,projected_artifacts_gib=.5,cpu_affinity=affinity,commands=[])
assert record['parent_allocated_gpu_hours']*3600+3*90<3600
def persist():
    record['audit_allocated_gpu_hours']=sum(c.get('seconds',0.) for c in record['commands'])/3600
    record['combined_allocated_gpu_hours']=record['parent_allocated_gpu_hours']+record['audit_allocated_gpu_hours']
    write_json(OUT/'campaign.json',record)
persist()
try:
    for index in range(3):
        assert record['combined_allocated_gpu_hours']*3600+90<=3600
        assert shutil.disk_usage(ROOT).free/2**30>=16.5
        resources,observations=wait_for_idle_gpu(2,primary['plan']['gpu_uuid'],timeout=10)
        assert float(resources['memory_free_mib'])>=16384
        assert resources['name']==primary['plan']['gpu_model']
        dest=OUT/f'repeat-{index+1}'
        command=[sys.executable,'-m','experiments.ablation.fidelity','--probe-space','policy',
            '--checkpoint',str(ROOT/'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt'),
            '--bank',str(ROOT/'runtime/policy-gradient-v1/h1-full-01/policy-bank.pt'),
            '--sample-indices','0','1','--gradient-horizon','32','--precision','fp32','--action-std','.1',
            '--estimator-seeds','30001','30002','--reference-seeds','40027','40001',
            '--convergence-counts','2','--directions','1','--direction-seed','50001',
            '--epsilons','.003','.01','.03','--repeats','3','--gpu','2',
            '--gpu-uuid',primary['plan']['gpu_uuid'],'--max-seconds','70','--output',str(dest)]
        item=dict(repeat=index+1,resources=resources,observations=observations,command=command,maximum_seconds=90)
        record['commands'].append(item);persist()
        env=os.environ.copy();env.update(OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',
            TORCHINDUCTOR_COMPILE_THREADS='4',ISAACSIM_ASSET_ROOT=str(REPO/'data/isaac-assets'),
            WARP_CACHE_PATH=str(ROOT/'runtime/policy-gradient-v1/cache/h1-full-01/warp'))
        execute_probe(item,OUT/f'repeat-{index+1}.log',gpu=2,cwd=REPO,environment=env,timeout=90,persist=persist)
        assert json.loads((dest/'probe.json').read_text())['status']=='complete'
    record['status']='complete'
except BaseException as exc:
    record.update(status='failed',error=f'{type(exc).__name__}: {exc}');raise
finally:
    persist()
