"""Run the 2x2 critic/direct-action-gradient ablations after H1/H8/H32 qualification, sharing the 0.25 GPU-hour cap."""
from pathlib import Path
import json,os,shutil,subprocess,sys
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023')
REPO=ROOT/'policy-gradient-repo'; OUT=ROOT/'runtime/policy-gradient-v1'
GPU_UUID='GPU-cc40495e-8e3b-d4c0-894a-63ce2fb079a9'
os.chdir(REPO);sys.path.insert(0,str(REPO))
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu,gpu_resources
from experiments.ablation.common import sha256
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='19305b7666312e136a58a14bec07f808a315847f'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
first=json.loads((OUT/'h1-full-01-allocation.json').read_text())
first_probe=json.loads((OUT/'h1-full-01/probe.json').read_text())
assert first['status']=='complete' and first['returncode']==0 and first_probe['status']=='complete'
BANK=OUT/'h1-full-01/policy-bank.pt'
assert sha256(BANK)=='8567f64d7e316d96b0e4b0c0014af2bcedb0be85d27626ec457f2b46287291d0'
CHECKPOINT=ROOT/'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt'
assert sha256(CHECKPOINT)==first['checkpoint_sha256']
qualified=json.loads((OUT/'horizon-campaign.json').read_text())
assert qualified['status']=='complete' and all(c['returncode']==0 for c in qualified['commands'])
prior_seconds=qualified['allocated_gpu_hours']*3600
record=dict(status='running',source=first['source'],gpu=2,gpu_uuid=GPU_UUID,
 seed=0,probe_seed=9001,indices=[0,1],horizons=[1,8,32],
 prior_allocated_seconds=prior_seconds,max_total_gpu_hours=.25,
 forecast_warm_seconds_per_case={'1':30,'8':36,'32':65},maximum_seconds_per_new_probe=90,
 variants=['no_critic','detach_action_reward','no_critic_and_detach_action_reward'],
 forecast_peak_memory_mib=8192,minimum_disk_reserve_gib=24,estimated_artifact_gib=5.0,
 bank_sha256=sha256(BANK),checkpoint_sha256=sha256(CHECKPOINT),commands=[])
receipt=OUT/'ablation-campaign.json'
assert not receipt.exists()
def persist():
 temp=receipt.with_suffix('.tmp');temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(receipt)
os.nice(10);affinity=sorted(os.sched_getaffinity(0))[-4:];os.sched_setaffinity(0,affinity)
record['cpu_affinity']=affinity;record['nice']=10;persist()
try:
 for horizon,variant,flags in [(h,v,f) for h in (1,8,32) for v,f in (('no-critic',['--no-critic']),('detach-action',['--detach-action-reward']),('no-critic-detach-action',['--no-critic','--detach-action-reward']))]:
  used=prior_seconds+sum(c['seconds'] for c in record['commands'])
  assert used+90<=900, 'No new process may exceed the cumulative cap'
  assert shutil.disk_usage(ROOT).free/2**30>25.0
  resources,observations=wait_for_idle_gpu(2,GPU_UUID,timeout=10.)
  assert float(resources['memory_free_mib'])>=16384
  dest=OUT/f'h{horizon}-{variant}-01'
  environment=os.environ.copy();environment.update(OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',
   TORCHINDUCTOR_COMPILE_THREADS='4',ISAACSIM_ASSET_ROOT=str(REPO/'data/isaac-assets'),
   WARP_CACHE_PATH=str(OUT/'cache/h1-full-01/warp'),TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/h1-full-01/inductor'))
  command=dict(resources=resources,observations=observations,formal_gpu_before=gpu_resources(0),
   cache_protocol='reuse qualified H1 cache; each full process cost is retained',
   command=[sys.executable,'-m','experiments.ablation.fidelity','--probe-space','policy','--checkpoint',str(CHECKPOINT),
   '--bank',str(BANK),'--sample-indices','0','1','--gradient-horizon',str(horizon),'--probe-seed','9001','--directions','2',
   '--epsilons','.001','.003','.01','--repeats','3','--gpu','2','--gpu-uuid',GPU_UUID,'--max-seconds','75','--output',str(dest),*flags])
  record['commands'].append(command);persist()
  execute_probe(command,OUT/f'h{horizon}-{variant}-01.log',gpu=2,cwd=REPO,environment=environment,timeout=90,persist=persist)
  command['formal_gpu_after']=gpu_resources(0);persist()
  assert json.loads((dest/'probe.json').read_text())['status']=='complete'
 record['status']='complete'
except BaseException as exc:
 record.update(status='failed',error=f'{type(exc).__name__}: {exc}');raise
finally:
 record['allocated_gpu_hours']=(prior_seconds+sum(c.get('seconds',0) for c in record['commands']))/3600
 persist()
