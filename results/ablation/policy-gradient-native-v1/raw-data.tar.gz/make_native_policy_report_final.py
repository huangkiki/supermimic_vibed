from pathlib import Path
import importlib.util,json,os,sys,time
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023');REPO=ROOT/'policy-gradient-repo';OUT=ROOT/'runtime/policy-gradient-v1'
os.nice(15);os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[-8:-4]);sys.path.insert(0,str(REPO))
import torch
torch.set_num_threads(4)
from experiments.ablation.common import sha256
assert json.loads((OUT/'precision-campaign.json').read_text())['status']=='complete'
paths=[OUT/f'h{h}-{variant}-01' for h in (1,8,32) for variant in ('full','no-critic','detach-action','no-critic-detach-action')]
spec=importlib.util.spec_from_file_location('experiments.ablation.analyze_policy_fidelity',OUT/'analyze_policy_fidelity.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
started=time.monotonic();sys.argv=['analyze_policy_fidelity',*map(str,paths),'--output',str(OUT/'analysis-training-v2')]
module.main()
precision_paths=[OUT/f'h{h}-full-fp32-01' for h in (1,8,32)]
sys.argv=['analyze_policy_fidelity',*map(str,precision_paths),'--output',str(OUT/'analysis-fp32-v1')]
module.main()
paths+=precision_paths
records=[]
for path in paths:
 records.append(dict(probe=path.name,files={name:dict(sha256=sha256(path/name),bytes=(path/name).stat().st_size)
  for name in ('gradients.pt','direction-rollouts.pt','policy-bank.pt','directions.csv','summary.json','probe.json')}))
receipt=dict(status='passed',seconds=time.monotonic()-started,cuda_initialized=torch.cuda.is_initialized(),
 analysis_source_sha256=sha256(OUT/'analyze_policy_fidelity.py'),probes=records,
 evidence='All 15 complete cases; raw vectors, paired rollouts, shared raw histories and CSV summaries verified on CPU')
(OUT/'all15-tensor-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(status='passed',seconds=receipt['seconds'],cases=len(paths))))
