"""One bounded diagnostic on idle GPU 2; never touches the formal GPU 0 queue."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/huangyue/work/supermimic-ablation-20261023')
REPO = ROOT / 'policy-gradient-repo'
DEST = ROOT / 'runtime/policy-gradient-v1/h1-full-01'
GPU_UUID = 'GPU-cc40495e-8e3b-d4c0-894a-63ce2fb079a9'
CHECKPOINT = ROOT / 'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt'
BANK = ROOT / 'trained-fidelity-repo/logs/ablation/trained-policy-fidelity-seed0-v1/gradient-components-full-h1/heldout-bank.pt'
os.chdir(REPO)
sys.path.insert(0, str(REPO))
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu, gpu_resources
from experiments.ablation.common import sha256
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == '19305b7666312e136a58a14bec07f808a315847f'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert sha256(CHECKPOINT) == '54d0854c1b4a8af9770b0c6f11c29d6ad8d0c9e6f870913e81234ac9caf0cbac'
assert sha256(BANK) == 'a79f08f281b288e8f8001aa994fc127789c080e42b67fa809dce1cbeb48d3abb'
assert shutil.disk_usage(ROOT).free / 2**30 > 25
resources, observations = wait_for_idle_gpu(2, GPU_UUID, timeout=10.)
assert float(resources['memory_free_mib']) >= 16384
os.nice(10)
affinity=sorted(os.sched_getaffinity(0))[-4:]
os.sched_setaffinity(0, affinity)
environment=os.environ.copy()
environment.update(OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4',
 TORCHINDUCTOR_COMPILE_THREADS='4', ISAACSIM_ASSET_ROOT=str(REPO/'data/isaac-assets'),
 WARP_CACHE_PATH=str(DEST.parent/'cache/h1-full-01/warp'),
 TORCHINDUCTOR_CACHE_DIR=str(DEST.parent/'cache/h1-full-01/inductor'))
record=dict(status='running', source='19305b7666312e136a58a14bec07f808a315847f',resources=resources,
 observations=observations, formal_gpu_before=gpu_resources(0),cpu_affinity=affinity,nice=10,
 checkpoint_sha256=sha256(CHECKPOINT),bank_sha256=sha256(BANK),max_seconds=600,
 projected_memory_mib=16384,projected_artifact_gib=1,minimum_disk_reserve_gib=24,
 command=[sys.executable,'-m','experiments.ablation.fidelity','--probe-space','policy',
 '--checkpoint',str(CHECKPOINT),'--bank',str(BANK),'--sample-indices','0','1',
 '--gradient-horizon','1','--probe-seed','9001','--directions','2','--epsilons','.001','.003','.01',
 '--repeats','3','--gpu','2','--gpu-uuid',GPU_UUID,'--max-seconds','580','--output',str(DEST)])
receipt=DEST.parent/'h1-full-01-allocation.json'
assert not receipt.exists() and not DEST.exists()
def persist():
 temp=receipt.with_suffix('.tmp')
 temp.write_text(json.dumps(record,indent=2)+'\n'); temp.replace(receipt)
persist()
try:
 execute_probe(record,DEST.parent/'h1-full-01.log',gpu=2,cwd=REPO,environment=environment,timeout=600,persist=persist)
 record['status']='complete'
except BaseException as exc:
 record.update(status='failed',error=f'{type(exc).__name__}: {exc}')
 raise
finally:
 record['formal_gpu_after']=gpu_resources(0)
 record['allocated_gpu_hours']=record.get('seconds',0)/3600
 persist()
