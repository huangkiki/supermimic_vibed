"""CPU-only full artifact verification, figures, and a small publication archive."""
from pathlib import Path
import json
import os
import sys
import tarfile
import time
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023');REPO=ROOT/'matched-gradient-v2-repo';OUT=ROOT/'runtime/matched-policy-v1'
os.chdir(REPO);sys.path.insert(0,str(REPO));os.nice(15);os.sched_setaffinity(0,{72,73,74,75})
import torch
torch.set_num_threads(4)
from experiments.ablation import analyze_policy_estimators as analysis
from experiments.ablation.common import sha256
campaign=json.loads((OUT/'corrected-campaign.json').read_text())
assert campaign['status']=='complete'
cases=[f'h{h}-full-02' for h in (1,8,32)]
started=time.perf_counter()
sys.argv=['analysis',*[str(OUT/name) for name in cases],'--output',str(OUT/'analysis-v1')]
analysis.main()
proof=dict(status='passed',seconds=time.perf_counter()-started,cuda_initialized=torch.cuda.is_initialized(),
 source_sha256=sha256(REPO/'experiments/ablation/analyze_policy_estimators.py'),probes=[])
for name in cases:
 proof['probes'].append(dict(probe=name,files={p.name:dict(sha256=sha256(p),bytes=p.stat().st_size)
  for p in sorted((OUT/name).iterdir()) if p.is_file()}))
(OUT/'all3-tensor-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
allocations=[json.loads((OUT/'h1-allocation.json').read_text()),
 *json.loads((OUT/'horizon-campaign.json').read_text())['commands'],
 json.loads((OUT/'score-audit-allocation.json').read_text()),*campaign['commands']]
assert len(allocations)==7
prior=allocations[0]['prior_diagnostic_gpu_hours']
seconds=sum(c['seconds'] for c in allocations)
assert abs(prior+seconds/3600-campaign['cumulative_diagnostic_gpu_hours'])<1e-12
cost=dict(completed_probe_processes=5,failed_probe_processes=1,score_audit_processes=1,
 total_processes=7,matched_comparison_process_seconds=seconds,matched_comparison_gpu_hours=seconds/3600,
 prior_deterministic_diagnostic_gpu_hours=prior,cumulative_diagnostic_gpu_hours=campaign['cumulative_diagnostic_gpu_hours'],
 cumulative_cap_gpu_hours=.5,validation_cpu_seconds=proof['seconds'],cuda_initialized_by_validation=proof['cuda_initialized'])
(OUT/'cost-reconciliation.json').write_text(json.dumps(cost,indent=2)+'\n')
small=[]
for name in ('h1-full-01','h8-full-01','h32-full-01',*cases):
 for p in (OUT/name).iterdir():
  if p.suffix in ('.json','.csv') or p.name in ('policy-bank.pt','physical-reference.pt'):
   small.append(p)
small.extend(p for p in OUT.iterdir() if p.is_file() and (p.suffix in ('.json','.py','.log') or p.name=='failed-h32-rollout.pt'))
small.extend(p for p in (OUT/'analysis-v1').iterdir() if p.is_file())
with tarfile.open(OUT/'small-raw-data.tar.gz','w:gz') as archive:
 for p in sorted(small):archive.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
print(json.dumps(dict(cost=cost,probes=proof['probes'],archive_bytes=(OUT/'small-raw-data.tar.gz').stat().st_size,
 archive_sha256=sha256(OUT/'small-raw-data.tar.gz'),archive_files=len(small)),indent=2))
