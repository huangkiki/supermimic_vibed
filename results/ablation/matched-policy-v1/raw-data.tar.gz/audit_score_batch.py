"""Isolate native old-logprob drift without initializing a physics simulator."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023');REPO=ROOT/'matched-gradient-repo';OUT=ROOT/'runtime/matched-policy-v1'
os.chdir(REPO);sys.path.insert(0,str(REPO))
os.environ['CUDA_VISIBLE_DEVICES']='2'
import torch
from experiments.ablation.common import Config,motion_files
from experiments.ablation.policy_fidelity import PolicyGradientProbe,parameter_vector
from experiments.ablation.policy_estimators import stochastic_probe,collect_score_rollout
from experiments.ablation.policy_fidelity_run import select_bank
from supermimic.kinematics import G1Kinematics
from supermimic.mdp import CRITIC_EXTRA,INV_DIM,MDP,OBS_DIM,normalize_xi,unflatten_state
from supermimic.motion import MotionLib
from supermimic.networks import Critic,Policy,WorldModel
from supermimic.robot import default_joint_pos_list
import supermimic.networks as networks
torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;networks.AMP_DTYPE=None
checkpoint=torch.load(ROOT/'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt',map_location='cuda:0',weights_only=False)
cfg=Config(**checkpoint['config']);kin=G1Kinematics('cuda:0');motion=MotionLib([str(p) for p in motion_files(cfg)],kin,'cuda:0');mdp=MDP(kin,motion,torch.tensor(default_joint_pos_list(),device='cuda:0'))
policy=Policy(OBS_DIM,73*cfg.goal_frames,cfg.hist).to('cuda:0');wm=WorldModel().to('cuda:0');critic=Critic(INV_DIM+CRITIC_EXTRA+73*cfg.goal_frames).to('cuda:0')
for key,module in (('pi',policy),('wm',wm),('critic',critic)):module.load_state_dict(checkpoint[key])
bank=select_bank(torch.load(ROOT/'runtime/policy-gradient-v1/h1-full-01/policy-bank.pt',map_location='cuda:0',weights_only=False),[0,1])
starts=dict(s=bank['state'],a_prev=bank['previous_action'],xi=bank['xi'],f=bank['frames'])
seed=9001+len(list((OUT/'h32-full-01').glob('estimate-*.pt')))
probe=PolicyGradientProbe(policy=policy,wm=wm,critic=critic,mdp=mdp,motion=motion,starts=starts,history=bank['replay_history'],unflatten_state=unflatten_state,normalize_xi=normalize_xi,horizon=32,gamma=cfg.gamma,goal_frames=cfg.goal_frames,seed=seed)
probe=stochastic_probe(probe,.1)
def digest():return hashlib.sha256(parameter_vector(policy).cpu().numpy().tobytes()).hexdigest()
before=digest();rollout=collect_score_rollout(probe)
with torch.no_grad():
 flat=probe.policy.log_prob(policy(rollout['obs'].flatten(0,1),rollout['goal'].flatten(0,1)),rollout['action'].flatten(0,1)).reshape_as(rollout['old_log_prob'])
 sequential=torch.stack([probe.policy.log_prob(policy(obs,goal),action) for obs,goal,action in zip(rollout['obs'],rollout['goal'],rollout['action'])])
after=digest()
result=dict(seed=seed,parameter_sha256_before=before,parameter_sha256_after=after,parameters_identical=before==after,
 flat_batch=64,original_step_batch=2,flat_max_logprob_error=float((flat-rollout['old_log_prob']).abs().max()),
 sequential_max_logprob_error=float((sequential-rollout['old_log_prob']).abs().max()),
 sequential_bitwise_equal=torch.equal(sequential,rollout['old_log_prob']),tf32=False)
torch.save({key:value.cpu() if torch.is_tensor(value) else value for key,value in rollout.items()},OUT/'failed-h32-rollout.pt')
(OUT/'score-batch-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
