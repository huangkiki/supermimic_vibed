from pathlib import Path
import json,os,sys,subprocess
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023');REPO=ROOT/'matched-gradient-repo';OUT=ROOT/'runtime/matched-policy-v1'
os.chdir(REPO);sys.path.insert(0,str(REPO))
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu,gpu_resources
prior=json.loads((OUT/'horizon-campaign.json').read_text())
assert prior['status']=='failed'
assert prior['cumulative_diagnostic_gpu_hours']*3600+90<=1800
resources,observations=wait_for_idle_gpu(2,'GPU-cc40495e-8e3b-d4c0-894a-63ce2fb079a9',timeout=10)
os.nice(10);os.sched_setaffinity(0,{76,77,78,79})
record=dict(status='running',prior_diagnostic_gpu_hours=prior['cumulative_diagnostic_gpu_hours'],maximum_seconds=90,forecast_seconds=[10,30],forecast_memory_mib=4096,resources=resources,observations=observations,formal_gpu_before=gpu_resources(0),command=[sys.executable,str(OUT/'audit_score_batch.py')])
receipt=OUT/'score-audit-allocation.json';assert not receipt.exists()
def persist():
 temp=receipt.with_suffix('.tmp');temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(receipt)
persist()
try:
 execute_probe(record,OUT/'score-audit.log',gpu=2,cwd=REPO,environment={**os.environ,'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4'},timeout=90,persist=persist)
 record['status']='complete'
except BaseException as exc:record.update(status='failed',error=str(exc));raise
finally:
 record['cumulative_diagnostic_gpu_hours']=record['prior_diagnostic_gpu_hours']+record.get('seconds',0)/3600
 record['formal_gpu_after']=gpu_resources(0);persist()
