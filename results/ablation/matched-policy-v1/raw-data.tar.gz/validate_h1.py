import importlib.util
import json
import os
from pathlib import Path
import sys
import time
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023')
OUT=ROOT/'runtime/matched-policy-v1'
os.chdir(ROOT/'matched-gradient-repo');sys.path.insert(0,str(Path.cwd()))
os.nice(15);os.sched_setaffinity(0,{72,73,74,75})
import torch
torch.set_num_threads(4)
from experiments.ablation.common import sha256
spec=importlib.util.spec_from_file_location('experiments.ablation.analyze_policy_estimators',OUT/'analysis-source.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
start=time.perf_counter();probe=module.load_comparison(OUT/'h1-full-01')
proof=dict(status='passed',seconds=time.perf_counter()-start,cuda_initialized=torch.cuda.is_initialized(),
 source_sha256=sha256(OUT/'analysis-source.py'),files={p.name:dict(sha256=sha256(p),bytes=p.stat().st_size) for p in sorted((OUT/'h1-full-01').iterdir()) if p.is_file()})
(OUT/'h1-tensor-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(dict(validation=proof['status'],seconds=proof['seconds'],cuda_initialized=proof['cuda_initialized'],
 rows=[r for r in probe['rows'] if r['epsilon']==.01]),indent=2))
