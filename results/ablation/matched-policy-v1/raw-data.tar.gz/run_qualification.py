"""One bounded H1 qualification; cumulative diagnostics cap includes the prior 15 probes."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023')
REPO=ROOT/'matched-gradient-repo'
OUT=ROOT/'runtime/matched-policy-v1'
UUID='GPU-cc40495e-8e3b-d4c0-894a-63ce2fb079a9'
os.chdir(REPO)
sys.path.insert(0,str(REPO))
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu,gpu_resources
from experiments.ablation.common import sha256
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='7a4df20b2bf102b0d7c4800f3a147f0d9b10c0db'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
prior=json.loads((ROOT/'runtime/policy-gradient-v1/precision-campaign.json').read_text())
assert prior['status']=='complete'
checkpoint=ROOT/'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt'
bank=ROOT/'runtime/policy-gradient-v1/h1-full-01/policy-bank.pt'
assert sha256(checkpoint)=='54d0854c1b4a8af9770b0c6f11c29d6ad8d0c9e6f870913e81234ac9caf0cbac'
assert sha256(bank)=='8567f64d7e316d96b0e4b0c0014af2bcedb0be85d27626ec457f2b46287291d0'
assert prior['allocated_gpu_hours']*3600+120<=1800
free=shutil.disk_usage(ROOT).free/2**30
assert free>25.5
resources,observations=wait_for_idle_gpu(2,UUID,timeout=10)
assert float(resources['memory_free_mib'])>=16384
os.nice(10)
affinity=sorted(os.sched_getaffinity(0))[-4:]
os.sched_setaffinity(0,affinity)
env=os.environ.copy()
env.update(OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TORCHINDUCTOR_COMPILE_THREADS='4',
 ISAACSIM_ASSET_ROOT=str(REPO/'data/isaac-assets'),
 WARP_CACHE_PATH=str(ROOT/'runtime/policy-gradient-v1/cache/h1-full-01/warp'),
 TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/inductor'))
record=dict(status='running',source=source,prior_diagnostic_gpu_hours=prior['allocated_gpu_hours'],
 cumulative_diagnostic_cap_gpu_hours=.5,maximum_seconds=120,forecast_seconds=[30,60],
 forecast_peak_memory_mib=8192,minimum_disk_reserve_gib=24,available_disk_gib=free,
 artifact_forecast_gib=.5,cpu_affinity=affinity,nice=10,resources=resources,observations=observations,
 checkpoint_sha256=sha256(checkpoint),bank_sha256=sha256(bank),formal_gpu_before=gpu_resources(0),
 cache_protocol='reuse previously qualified Warp cache; full process cost retained',
 command=[sys.executable,'-m','experiments.ablation.fidelity','--probe-space','policy','--checkpoint',str(checkpoint),
 '--bank',str(bank),'--sample-indices','0','1','--gradient-horizon','1','--precision','fp32','--action-std','.1',
 '--estimator-seeds','9001','9002','9003','9004','--reference-seeds','19001','19002','19003','19004',
 '--epsilons','.001','.003','.01','--repeats','3','--gpu','2','--gpu-uuid',UUID,'--max-seconds','110',
 '--output',str(OUT/'h1-full-01')])
receipt=OUT/'h1-allocation.json'
assert not receipt.exists()
def persist():
 p=receipt.with_suffix('.tmp');p.write_text(json.dumps(record,indent=2)+'\n');p.replace(receipt)
persist()
try:
 execute_probe(record,OUT/'h1-full-01.log',gpu=2,cwd=REPO,environment=env,timeout=120,persist=persist)
 probe=json.loads((OUT/'h1-full-01/probe.json').read_text())
 assert probe['status']=='complete' and probe['estimator_comparison']['status']=='complete'
 record['status']='complete'
except BaseException as exc:
 record.update(status='failed',error=f'{type(exc).__name__}: {exc}')
 raise
finally:
 record['cumulative_diagnostic_gpu_hours']=prior['allocated_gpu_hours']+record.get('seconds',0)/3600
 record['formal_gpu_after']=gpu_resources(0)
 persist()
