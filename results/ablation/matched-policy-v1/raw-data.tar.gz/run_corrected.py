"""Requalify all three horizons after the batch-shape fix; include ALL prior diagnostics in the 0.5 GPU-hour cap."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
ROOT=Path('/home/huangyue/work/supermimic-ablation-20261023')
REPO=ROOT/'matched-gradient-v2-repo'
OUT=ROOT/'runtime/matched-policy-v1'
UUID='GPU-cc40495e-8e3b-d4c0-894a-63ce2fb079a9'
os.chdir(REPO);sys.path.insert(0,str(REPO))
from experiments.ablation.run_fidelity_cohort import execute_probe
from experiments.ablation.run_suite import wait_for_idle_gpu,gpu_resources
from experiments.ablation.common import sha256
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='3c294d1cdf6e1153da2e79b9292e2b586b69c177'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
first=json.loads((OUT/'score-audit-allocation.json').read_text())
qualification=json.loads((OUT/'h1-allocation.json').read_text())
assert first['status']=='complete' and first['returncode']==0
bank=ROOT/'runtime/policy-gradient-v1/h1-full-01/policy-bank.pt'
checkpoint=ROOT/'formal-repo/logs/ablation/formal-locomotion-seed0-v1/supermimic-seed0/ckpt_004000.pt'
assert sha256(bank)==qualification['bank_sha256'] and sha256(checkpoint)==qualification['checkpoint_sha256']
os.nice(10);affinity=sorted(os.sched_getaffinity(0))[-4:];os.sched_setaffinity(0,affinity)
record=dict(status='running',source=source,gpu_uuid=UUID,cumulative_diagnostic_cap_gpu_hours=.5,
 prior_diagnostic_gpu_hours=first['cumulative_diagnostic_gpu_hours'],minimum_disk_reserve_gib=24,
 forecast_h1_seconds=[35,75],forecast_h8_seconds=[70,130],forecast_h32_seconds=[180,300],forecast_peak_memory_mib=8192,
 artifact_forecast_gib_per_probe=1.5,cpu_affinity=affinity,nice=10,commands=[])
receipt=OUT/'corrected-campaign.json';assert not receipt.exists()
def persist():
 p=receipt.with_suffix('.tmp');p.write_text(json.dumps(record,indent=2)+'\n');p.replace(receipt)
persist()
try:
 for horizon,maximum in ((1,120),(8,240),(32,480)):
  used=record['prior_diagnostic_gpu_hours']*3600+sum(c['seconds'] for c in record['commands'])
  assert used+maximum<=1800
  assert shutil.disk_usage(ROOT).free/2**30>25.5
  resources,observations=wait_for_idle_gpu(2,UUID,timeout=10)
  assert float(resources['memory_free_mib'])>=16384
  env=os.environ.copy();env.update(OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',TORCHINDUCTOR_COMPILE_THREADS='4',
   ISAACSIM_ASSET_ROOT=str(REPO/'data/isaac-assets'),
   WARP_CACHE_PATH=str(ROOT/'runtime/policy-gradient-v1/cache/h1-full-01/warp'),TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/inductor'))
  dest=OUT/f'h{horizon}-full-02'
  command=dict(horizon=horizon,resources=resources,observations=observations,formal_gpu_before=gpu_resources(0),
   maximum_seconds=maximum,command=[sys.executable,'-m','experiments.ablation.fidelity','--probe-space','policy',
    '--checkpoint',str(checkpoint),'--bank',str(bank),'--sample-indices','0','1','--gradient-horizon',str(horizon),
    '--precision','fp32','--action-std','.1','--estimator-seeds',*[str(s) for s in range(9001,9017)],
    '--reference-seeds',*[str(s) for s in range(19001,19017)],'--epsilons','.001','.003','.01','--repeats','3',
    '--gpu','2','--gpu-uuid',UUID,'--max-seconds',str(maximum-10),'--output',str(dest)])
  record['commands'].append(command);persist()
  execute_probe(command,OUT/f'h{horizon}-full-02.log',gpu=2,cwd=REPO,environment=env,timeout=maximum,persist=persist)
  command['formal_gpu_after']=gpu_resources(0);persist()
  assert json.loads((dest/'probe.json').read_text())['status']=='complete'
 record['status']='complete'
except BaseException as exc:
 record.update(status='failed',error=f'{type(exc).__name__}: {exc}');raise
finally:
 record['cumulative_diagnostic_gpu_hours']=record['prior_diagnostic_gpu_hours']+sum(c.get('seconds',0) for c in record['commands'])/3600
 persist()
